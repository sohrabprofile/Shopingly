var MainImg = document.querySelector('#MainImg');
var price = document.querySelector('.price')
var item_name = document.querySelector('.item-name')
let src = localStorage.getItem('item');

MainImg.setAttribute('src', src.split(',')[0])
price.textContent = `$${src.split(',')[1]}.00`
item_name.textContent = `${src.split(',')[2]}`
// console.log(item_name)
// var small_img_group = document.querySelector('.small-img-group');

// small_img_group.addEventListener('click', e => {
//     MainImg.setAttribute('src', e.target.src)
// });

const original_price = parseInt(price.textContent.split(',')[0].split('$')[1])


var sProduct = document.querySelector('.sproduct')
var input = document.querySelector('input')
input.addEventListener('input', e => {
    let new_price = original_price * parseInt(e.target.value)
    let final_price = parseInt(new_price)
    if (parseInt(e.target.value) > 10) {
        price.textContent = 'Out of Stock'
    }
    else if (parseInt(e.target.value) < 1) {
        e.target.value = 1
    }
    else {
        price.textContent = `$${final_price}.00`
    }
})

sProduct.addEventListener('click', e => {
    if (e.target.tagName === 'BUTTON') {
        var img_src = document.querySelector('#MainImg').getAttribute('src');
        var price = document.querySelector('.price').textContent
        var item_name = document.querySelector('.item-name').textContent
        var item_count = document.querySelector('input').value
        var cart_items = [img_src, price, item_name, item_count, original_price]
        localStorage.setItem('cart_items', cart_items)
    }
})
