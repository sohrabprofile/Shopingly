// var shop_page_event = document.querySelector('.shop-page-event')

// shop_page_event.addEventListener('click', e => {
//     if(e.target.tagName === 'IMG'){
//         let src = e.target.getAttribute('src')
//         localStorage.setItem('name', src)
//         document.location.href = 'sproduct.html'
//     }
// })


        